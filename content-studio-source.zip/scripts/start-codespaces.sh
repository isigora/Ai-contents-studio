#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
node scripts/setup-codespaces.mjs
mkdir -p .data
if curl -fsS http://localhost:4173/ -o /dev/null; then
  echo "Content Studio is already running on port 4173."
  exit 0
fi
nohup pnpm dev > .data/dev-server.log 2>&1 < /dev/null &
echo "Content Studio is starting. Open port 4173 from the Ports panel."
